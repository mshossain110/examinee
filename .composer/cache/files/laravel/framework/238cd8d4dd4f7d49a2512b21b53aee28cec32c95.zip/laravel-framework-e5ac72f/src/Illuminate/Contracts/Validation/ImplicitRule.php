<?php

namespace Illuminate\Contracts\Validation;

/**
 * @deprecated see ValidationRule
 */
interface ImplicitRule extends Rule
{
    //
}
