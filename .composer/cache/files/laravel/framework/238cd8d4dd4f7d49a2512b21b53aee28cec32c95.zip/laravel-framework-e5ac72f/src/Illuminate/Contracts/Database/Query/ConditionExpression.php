<?php

namespace Illuminate\Contracts\Database\Query;

interface ConditionExpression extends Expression
{
}
